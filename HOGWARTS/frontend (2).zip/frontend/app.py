from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import os
from datetime import datetime
import logging

app = Flask(__name__)
app.secret_key = 'gryffin-twin-secret-key-change-in-production'

# Explicit session cookie settings to avoid browser cookie/SameSite issues during local dev
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_SECURE'] = False
app.config['SESSION_COOKIE_HTTPONLY'] = True

# Enable debug logging for tracing login/session behavior
logging.basicConfig(level=logging.DEBUG)
app.logger.setLevel(logging.DEBUG)

# Demo users database
USERS = {
    'user@example.com': {
        'password': generate_password_hash('password123'),
        'name': 'Harry Potter'
    },
    'hermione@gryffindor.com': {
        'password': generate_password_hash('gryffindor123'),
        'name': 'Hermione Granger'
    },
    'ron@gryffindor.com': {
        'password': generate_password_hash('potter123'),
        'name': 'Ron Weasley'
    }
}

# Demo dashboard data
DASHBOARD_DATA = {
    'total_balance': 24580,
    'expenses': 3240,
    'investments': 12450,
    'goals_progress': 68,
    'financial_score': 850,
    'accounts': [
        {'name': 'Checking Account', 'type': 'Checking', 'balance': 5230, 'status': 'Active'},
        {'name': 'Savings Account', 'type': 'Savings', 'balance': 12350, 'status': 'Active'},
        {'name': 'Money Market', 'type': 'Money Market', 'balance': 4800, 'status': 'Active'},
        {'name': 'Business Account', 'type': 'Business', 'balance': 2200, 'status': 'Active'}
    ]
}

EXPENSES_DATA = [
    {'date': 'Dec 05, 2025', 'category': 'Food', 'description': 'Lunch at Restaurant', 'amount': 45.50, 'status': 'Completed'},
    {'date': 'Dec 04, 2025', 'category': 'Transport', 'description': 'Uber Trip', 'amount': 32.00, 'status': 'Completed'},
    {'date': 'Dec 03, 2025', 'category': 'Entertainment', 'description': 'Movie Tickets', 'amount': 28.00, 'status': 'Completed'},
    {'date': 'Dec 02, 2025', 'category': 'Shopping', 'description': 'Grocery Shopping', 'amount': 156.75, 'status': 'Completed'},
    {'date': 'Dec 01, 2025', 'category': 'Health', 'description': 'Pharmacy Purchase', 'amount': 65.20, 'status': 'Completed'},
    {'date': 'Nov 30, 2025', 'category': 'Education', 'description': 'Online Course', 'amount': 99.99, 'status': 'Pending'}
]

# ===== ROUTES =====

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')

        # Validate input
        if not email or not password:
            error = '⚠️ Please fill in all fields'
        else:
            # Check user credentials
            user = USERS.get(email)
            if not user or not check_password_hash(user['password'], password):
                error = '⚠️ Invalid email or password'
            else:
                # Authentication successful
                session['user_id'] = email
                session['user_name'] = user['name']
                app.logger.info('User logged in: %s', email)
                app.logger.debug('Session after login: %s', dict(session))
                return redirect(url_for('dashboard'))

    return render_template('login.html', error=error)

@app.route('/dashboard')
def dashboard():
    app.logger.debug('Dashboard accessed; session keys=%s', list(session.keys()))
    if 'user_id' not in session:
        app.logger.info('Unauthorized dashboard access attempt; redirecting to login')
        return redirect(url_for('login'))
    
    return render_template('dashboard.html', 
                         user_name=session['user_name'],
                         user_email=session['user_id'],
                         dashboard_data=DASHBOARD_DATA)

@app.route('/expenses')
def expenses():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    total_expenses = sum(exp['amount'] for exp in EXPENSES_DATA)
    
    return render_template('expenses.html', 
                         user_name=session['user_name'],
                         user_email=session['user_id'],
                         expenses=EXPENSES_DATA,
                         total_expenses=total_expenses,
                         budget=4200)

@app.route('/analytics')
def analytics():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('analytics.html', 
                         user_name=session['user_name'],
                         user_email=session['user_id'])

@app.route('/goals')
def goals():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('goals.html', 
                         user_name=session['user_name'],
                         user_email=session['user_id'])

@app.route('/security')
def security():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('security.html', 
                         user_name=session['user_name'],
                         user_email=session['user_id'])

@app.route('/portfolio')
def portfolio():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('portfolio.html', 
                         user_name=session['user_name'],
                         user_email=session['user_id'])

@app.route('/myfam')
def myfam():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('myfam.html', 
                         user_name=session['user_name'],
                         user_email=session['user_id'])

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# ===== API ENDPOINTS =====

@app.route('/api/dashboard-data')
def api_dashboard_data():
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    return jsonify(DASHBOARD_DATA)

@app.route('/api/expenses')
def api_expenses():
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    total = sum(exp['amount'] for exp in EXPENSES_DATA)
    return jsonify({'expenses': EXPENSES_DATA, 'total': total})

@app.route('/api/user-info')
def api_user_info():
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    return jsonify({
        'name': session['user_name'],
        'email': session['user_id']
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)

# cd "C:\Users\ASUS\Documents\HOGWARTS[1]\HOGWARTS\frontend"
# python -m venv .venv
# .venv\Scripts\activate
# pip install flask werkzeug
# python app.py
