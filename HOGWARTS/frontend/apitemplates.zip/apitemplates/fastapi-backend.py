"""
GryffinTwin - FastAPI Backend Sample
This is a starter template for your FastAPI backend

Install dependencies:
pip install fastapi uvicorn python-jose pydantic python-multipart

Run the server:
uvicorn main:app --reload
"""

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthCredentials
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime, timedelta
from jose import JWTError, jwt
import os

# Configuration
SECRET_KEY = "your-secret-key-change-this"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Initialize FastAPI app
app = FastAPI(title="GryffinTwin API")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

security = HTTPBearer()

# ============ MODELS ============

class User(BaseModel):
    id: int
    name: str
    email: str

class LoginRequest(BaseModel):
    email: str
    password: str

class LoginResponse(BaseModel):
    access_token: str
    token_type: str
    user: User

class DashboardSummary(BaseModel):
    total_balance: float
    balance_change: float
    monthly_expenses: float
    budget_percentage: int
    investments: float
    investment_return: float
    goals_progress: int
    active_goals: int
    security_status: str
    financial_score: int

class Expense(BaseModel):
    date: str
    category: str
    description: str
    amount: float
    status: str

class ExpensesResponse(BaseModel):
    total_expenses: float
    monthly_budget: float
    remaining_budget: float
    budget_percentage: int
    expenses: List[Expense]

class SecurityResponse(BaseModel):
    overall_security: str
    login_activity: str
    fraud_alerts: int
    password_strength: str
    two_factor_auth: bool
    monitored_cards: int

class Goal(BaseModel):
    id: int
    name: str
    icon: str
    target_amount: float
    current_amount: float
    status: str

class GoalsResponse(BaseModel):
    goals: List[Goal]

class AnalyticsResponse(BaseModel):
    total_income: float
    total_expenses: float
    net_savings: float
    savings_rate: int
    months: List[str]
    income_data: List[float]
    expense_data: List[float]
    categories: List[str]
    category_amounts: List[float]

# ============ AUTHENTICATION ============

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def verify_token(credentials: HTTPAuthCredentials = Depends(security)):
    try:
        token = credentials.credentials
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        return email
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

# ============ ROUTES ============

@app.get("/")
def read_root():
    return {"message": "GryffinTwin API is running"}

@app.post("/api/auth/login", response_model=LoginResponse)
def login(request: LoginRequest):
    """
    Login endpoint - Validates credentials and returns JWT token
    
    For demo purposes, accepting any email/password.
    Replace with actual database validation in production.
    """
    # TODO: Validate credentials against database
    # This is just a demo - replace with real authentication
    
    if not request.email or not request.password:
        raise HTTPException(status_code=400, detail="Email and password required")
    
    # Create mock user
    user = User(id=1, name="Test User", email=request.email)
    
    # Create access token
    access_token = create_access_token(
        data={"sub": request.email},
        expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    
    return LoginResponse(
        access_token=access_token,
        token_type="bearer",
        user=user
    )

@app.get("/api/dashboard/summary", response_model=DashboardSummary)
def get_dashboard_summary(email: str = Depends(verify_token)):
    """
    Get dashboard summary data for the authenticated user
    """
    return DashboardSummary(
        total_balance=24580.00,
        balance_change=12.5,
        monthly_expenses=3240.00,
        budget_percentage=78,
        investments=12450.00,
        investment_return=8.2,
        goals_progress=68,
        active_goals=4,
        security_status="Secure",
        financial_score=850
    )

@app.get("/api/expenses", response_model=ExpensesResponse)
def get_expenses(email: str = Depends(verify_token)):
    """
    Get expenses for the authenticated user
    """
    expenses = [
        Expense(
            date="2025-12-05",
            category="🍔 Food",
            description="Lunch at Restaurant",
            amount=45.50,
            status="✓ Completed"
        ),
        Expense(
            date="2025-12-04",
            category="🚗 Transport",
            description="Uber Trip",
            amount=32.00,
            status="✓ Completed"
        ),
        Expense(
            date="2025-12-03",
            category="🎬 Entertainment",
            description="Movie Tickets",
            amount=28.00,
            status="✓ Completed"
        ),
    ]
    
    return ExpensesResponse(
        total_expenses=3240.00,
        monthly_budget=4200.00,
        remaining_budget=960.00,
        budget_percentage=77,
        expenses=expenses
    )

@app.get("/api/security", response_model=SecurityResponse)
def get_security(email: str = Depends(verify_token)):
    """
    Get security status for the authenticated user
    """
    return SecurityResponse(
        overall_security="Excellent",
        login_activity="Normal",
        fraud_alerts=0,
        password_strength="Strong",
        two_factor_auth=True,
        monitored_cards=4
    )

@app.get("/api/goals", response_model=GoalsResponse)
def get_goals(email: str = Depends(verify_token)):
    """
    Get financial goals for the authenticated user
    """
    goals = [
        Goal(
            id=1,
            name="Emergency Fund",
            icon="🏦",
            target_amount=15000.00,
            current_amount=10200.00,
            status="Active"
        ),
        Goal(
            id=2,
            name="Vacation Fund",
            icon="✈️",
            target_amount=8000.00,
            current_amount=3600.00,
            status="Active"
        ),
        Goal(
            id=3,
            name="Home Down Payment",
            icon="🏠",
            target_amount=50000.00,
            current_amount=16000.00,
            status="Active"
        ),
    ]
    
    return GoalsResponse(goals=goals)

@app.get("/api/analytics", response_model=AnalyticsResponse)
def get_analytics(email: str = Depends(verify_token)):
    """
    Get financial analytics for the authenticated user
    """
    return AnalyticsResponse(
        total_income=18500.00,
        total_expenses=9240.00,
        net_savings=9260.00,
        savings_rate=50,
        months=["Week 1", "Week 2", "Week 3", "Week 4", "Week 5", "Week 6"],
        income_data=[1500, 1600, 1550, 1800, 1700, 1900],
        expense_data=[750, 780, 820, 750, 900, 800],
        categories=["Shopping", "Food", "Transport", "Entertainment", "Healthcare", "Other"],
        category_amounts=[2450, 1890, 1560, 980, 720, 640]
    )

# Health check endpoint
@app.get("/api/health")
def health_check():
    return {"status": "ok", "timestamp": datetime.utcnow()}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)